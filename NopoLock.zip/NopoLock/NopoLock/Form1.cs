﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NopoLock
{
    public partial class Form1 : Form
    {
        private Client client;
        public Form1()
        {
            InitializeComponent();
            this.client = new Client(this);
            new Thread(client.Run).Start();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "All Files (*.*)|*.*";

            DialogResult result = openFileDialog.ShowDialog();

            if (result == DialogResult.OK)
            {
                // User selected a file, do something with it
                string selectedFile = openFileDialog.FileName;
                // for example, display the file name in a label
                this.fileSeclectBox.Text = selectedFile;
                String[] request = { "PUSH", selectedFile };
                this.client.SendRequest(request);

                //selectedFile. = selectedFile;
            }

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            using (var folderBrowserDialog = new FolderBrowserDialog())
            {
                folderBrowserDialog.Description = "Select a folder.";
                folderBrowserDialog.ShowNewFolderButton = false;
                folderBrowserDialog.RootFolder = Environment.SpecialFolder.MyComputer;

                if (folderBrowserDialog.ShowDialog() == DialogResult.OK)
                {
                    // User selected a folder, display the folder path in a label
                    string selectedFolder = folderBrowserDialog.SelectedPath;
                    this.folderSelectBox.Text = selectedFolder;
                }
            }
        }
        private void fileListBox_MouseDoubleClick(object sender, EventArgs e)
        {
            // Check if an item in the list is selected
            if (fileListBox.SelectedItem != null)
            {
                // Retrieve the text of the selected item
                string selectedFile = fileListBox.SelectedItem.ToString();

                Form prompt = new Form();
                prompt.Width = 250;
                prompt.Height = 200;
                prompt.Text = "Lock File";

                Label textLabel = new Label() { Left = 20, Top = 18, Text = "Lock time" };

                ComboBox timeUnitsBox = new ComboBox() { Left = 20, Top = 42, Width = 75 , DropDownStyle = ComboBoxStyle.DropDownList };
                timeUnitsBox.Items.Add("Minutes");
                timeUnitsBox.Items.Add("Hours");
                timeUnitsBox.Items.Add("Days");
                timeUnitsBox.SelectedIndex = 1;


                TextBox inputBox = new TextBox() { Left = 20, Top = 80, Width = 200 };
                Button submitButton = new Button() { Text = "Submit", Left = 20, Width = 100, Top = 120 };
                Button cancelButton = new Button() { Text = "Cancel", Left = 130, Width = 100, Top = 120 };

                submitButton.Click += (senderr, ee) => { prompt.DialogResult = DialogResult.OK; };
                cancelButton.Click += (senderr, ee) => { prompt.DialogResult = DialogResult.Cancel; };


                prompt.Controls.Add(textLabel);
                prompt.Controls.Add(timeUnitsBox);
                prompt.Controls.Add(inputBox);
                prompt.Controls.Add(submitButton);
                prompt.Controls.Add(cancelButton);

                // Set up the button event handlers
                


                // Show the form as a dialog box and get the user's input
                DialogResult result = prompt.ShowDialog();
                if (result == DialogResult.OK)
                {

                    int minutes;
                    if (int.TryParse(inputBox.Text, out minutes))
                    {
                        int timeSet = minutes;

                        if (timeUnitsBox.SelectedIndex == 1)
                            timeSet *= 60;
                        else if (timeUnitsBox.SelectedIndex == 2)
                            timeSet *= 60 * 24;

                        string[] request = { "SET", selectedFile, timeSet.ToString() };
                        client.SendRequest(request);
                    }
                    else
                    {
                        // User entered an invalid value, display an error message or take appropriate action
                    }
                }
            }
        }
        private void button3_Click(object sender, EventArgs e)
        {
            if (fileListBox.SelectedItems.Count > 0)
            {
                fileListBox.Refresh();
                string selectedFile = fileListBox.SelectedItems[0].ToString();
                if (folderSelectBox.Text.Length > 0)
                {
                    string[] request = { "CLONE", selectedFile, folderSelectBox.Text };

                    client.SendRequest(request);
                }
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            if (fileListBox.SelectedItems.Count > 0)
            {
                fileListBox.Refresh();
                string selectedFile = fileListBox.SelectedItems[0].ToString();
                
                string[] request = { "CHECK", selectedFile };
                client.SendRequest(request);
            }
        }


    }
}

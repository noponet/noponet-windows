﻿using System.Diagnostics;
using System.IO;
using System;
using System.Management;
using System.Threading;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;

class Program
{
    private string[] whitelistArray = {"C:\\Program Files (x86)",
            "C:\\Program Files",
            "C:\\Windows",
            "C:\\PROGRA~2",
            "C:\\PROGRA~1"};
    List<string> blocked = new List<String>();
    List<string> fireWallRules;
    private string[] blockList;
    private string[] admins;
    private string[] admin_dirs;
    static void Main(string[] args)
    {
        Program p = new Program();
        p.start();

    }
    static void disableExe(object parammies)
    {
        string user = ((string[])parammies)[2];
        string exeName = ((string[])parammies)[1];
    }
    private void setupBlockedList()
    {
        string filePath = @"C:\Program Files (x86)\noponet\config_nopowall";
        List<string> blocked_list = new List<string>();
        if (File.Exists(filePath))
        {
            try
            {
                // Open the file using a stream reader
                using (StreamReader sr = new StreamReader(filePath))
                {
                    // Read the stream to a string, and write the string to the console
                    string line;
                    while ((line = sr.ReadLine()) != null)
                    {
                        if (line.StartsWith("block>"))
                        {
                            string[] blockParams = line.Split('>');

                            blocked_list.Add(blockParams[1]);
                            //Thread myThread = new Thread(new ParameterizedThreadStart(disableExe));
                            //myThread.Start(blockParams);
                        }
                    }
                }

                this.blockList = blocked_list.ToArray();
            }
            catch (Exception e)
            {
                Console.WriteLine("The file could not be read:");
                Console.WriteLine(e.Message);
            }
        }
    }
    private List<string> getFirewallRules()
    {
        List<string> rules = new List<string>();
        Process process = new Process();
        process.StartInfo.FileName = "cmd.exe";
        process.StartInfo.Arguments = "/c netsh advfirewall firewall show rule name=all dir=out | find \"Block\"";
        process.StartInfo.UseShellExecute = false;
        process.StartInfo.RedirectStandardOutput = true;
        process.StartInfo.CreateNoWindow = true;
        process.Start();

        StreamReader reader = process.StandardOutput;
        String line;

        while (!reader.EndOfStream)
        {

            line = reader.ReadLine();
            if (line.Contains("Rule Name:"))
            {
                int startIndex = line.IndexOf("Block ") + 6;
                int endIndex = line.IndexOf(" Outbound Connections");
                string path = line.Substring(startIndex, endIndex - startIndex);

                rules.Add(path);
            }
        }
        process.Dispose();
        return rules;
    }
    public void start()
    {
        admins = GetAdmins();
        admin_dirs = new string[admins.Length];
        setupBlockedList();

        for (int i = 0; i < admins.Length; i++)
        {
            admin_dirs[i] = "C:\\Users\\" + admins[i];
        }
        this.whitelistArray = this.whitelistArray.Concat(admin_dirs).ToArray();
        fireWallRules = this.getFirewallRules();
        foreach(string f in fireWallRules)
        {
            Console.WriteLine(f + "!");
        }

        using (ManagementEventWatcher processStartEventWatcher = new ManagementEventWatcher(new WqlEventQuery("SELECT * FROM Win32_ProcessStartTrace")))
        {

            // Set up the event handler for when a new process starts
            processStartEventWatcher.EventArrived += ProcessStartEventWatcher_EventArrived;

            // Start listening for process start events
            processStartEventWatcher.Start();

            Console.WriteLine("Listening for new processes starting...");

            Console.ReadLine();
            processStartEventWatcher.Stop();
        }
    }

    private void ProcessStartEventWatcher_EventArrived(object sender, EventArrivedEventArgs e)
    {
        // Get the process ID and process name from the event arguments
        int processId = Convert.ToInt32(e.NewEvent.Properties["ProcessID"].Value);
        string processName = e.NewEvent.Properties["ProcessName"].Value.ToString();

        try
        {
            Process process = Process.GetProcessById(processId);
            string processDirectory = Path.GetDirectoryName(process.MainModule.FileName);

            string programFiles = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles);
            string programFilesX86 = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86);
            string windowsFolder = Environment.GetFolderPath(Environment.SpecialFolder.Windows);


            string process_dir = processDirectory + "\\" + processName;
            if (!whiteListed(process_dir, processId))
            {
                TerminateProcessByPID(processId);
                Console.WriteLine(process_dir + " terminated.");
                if (!blocked.Contains(process_dir) && !fireWallRules.Contains(process_dir))
                {
                    

                    blocked.Add(process_dir);
                    process = new Process();
                    Console.WriteLine(process_dir + " added to firewall");
                    process.StartInfo.FileName = "netsh";
                    process.StartInfo.Arguments = "advfirewall firewall add rule name=\"Block " + process_dir + " Outbound Connections\" dir=out program=\"" + process_dir + "\" action=block";
                    process.StartInfo.UseShellExecute = false;
                    process.StartInfo.RedirectStandardOutput = true;
                    process.StartInfo.CreateNoWindow = true;
                    process.Start();
                    process.WaitForExit();
                    process.Dispose();
                }
            }
            
            
        }
        catch (Exception ex)
        {
            //Console.WriteLine($"Failed to getocess information for {processName}: {ex.Message}");
        }
    }
    private bool whiteListed(string exePath, int pid)
    {
        bool whiteListed = false;

        foreach (string white in whitelistArray)
        {
            if (exePath.StartsWith(white))
            {
                //Console.WriteLine(programPath);
                whiteListed = true;
            }
            foreach (string black in blockList)
            {
                string OGname = originalFileName(exePath);

                if (OGname == null)
                    OGname = "null";
                if (((OGname.Equals(black) || exePath.EndsWith(black)) && !exePath.StartsWith("C:\\Program Files\\Chromium\\Application")))
                    
                {
                    

                    whiteListed = false;
                    //TerminateProcessByPID(pid);
                }
                
            }
        }
        return whiteListed;
    }
    private static void TerminateProcessByPID(int pid)
    {
        try
        {
            // Get the process by its ID
            Process process = Process.GetProcessById(pid);

            // Terminate the process
            process.Kill();

            // Wait for the process to exit
            process.WaitForExit();

        }
        catch (ArgumentException)
        {
            Console.WriteLine($"No process with PID {pid} is currently running.");
        }
        catch (InvalidOperationException)
        {
            Console.WriteLine($"The process with PID {pid} has already exited.");
        }
        catch (System.ComponentModel.Win32Exception ex)
        {
            Console.WriteLine($"Failed to terminate process with PID {pid}: {ex.Message}");
        }
    }
    private static string originalFileName(string exePath)
    {
        try
        {
            var versionInfo = FileVersionInfo.GetVersionInfo(exePath);
            return versionInfo.OriginalFilename;
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Failed to get metadata for {exePath}: {ex.Message}");
        }
        return null;
    }
    static string[] GetAdmins()
    {
        Process process = new Process();
        process.StartInfo.FileName = "net";
        process.StartInfo.Arguments = "localgroup Administrators";
        process.StartInfo.UseShellExecute = false;
        process.StartInfo.RedirectStandardOutput = true;
        process.StartInfo.CreateNoWindow = true;
        process.Start();

        StreamReader reader = process.StandardOutput;
        String line;
        bool readingUsers = false;
        List<string> admins = new List<string>();
        while (!reader.EndOfStream)
        {
            line = reader.ReadLine();


            if (line.Equals("The command completed successfully."))
            {
                readingUsers = false;
                break;
            }


            if (readingUsers)
            {
                admins.Add(line);
            }
            if (line.Equals("Administrator"))
            {
                readingUsers = true;
            }


        }
        return admins.ToArray();
    }

}